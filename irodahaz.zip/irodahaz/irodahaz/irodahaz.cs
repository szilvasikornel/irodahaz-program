﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace irodahaz
{
    internal class Irodahaz
    {
        public string ceg { get; set; }
        public int kezdet { get; set; }
        public List<int> letszamadat { get; set; }

        public Irodahaz(string sor)
        {
            var v = sor.Split(' ');

            ceg = v[0];
            kezdet = int.Parse(v[1]);
            letszamadat = new List<int>();
            for (int i = 2; i < v.Length; i++)
            {
                letszamadat.Add(int.Parse(v[i]));
            }
        }
        public override string ToString()
        {
            string sor = string.Empty;
            sor += $"{ceg} {kezdet} ";
            for (int i = 0; i < letszamadat.Count; i++)
            {
                sor += letszamadat[i];
                sor += " ";
            }

            return sor;
        }
    }
}
