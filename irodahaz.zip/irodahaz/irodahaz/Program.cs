﻿using irodahaz;
using System.Text;

List<Irodahaz> irodahazak = new();

using StreamReader sr = new(@"..\..\..\src\irodahaz.txt", Encoding.UTF8);
while (!sr.EndOfStream) irodahazak.Add(new(sr.ReadLine()));

foreach (var i in irodahazak)
{
    Console.WriteLine(i);
}
Console.WriteLine("\n\n\n");

//8. Melyik emeleten dolgoznak a legtöbben? Írd ki az emelet számát a képernyőre.

int max = irodahazak[0].letszamadat.Sum();
int szamlalo = 0;
int emeletszam = 0;
foreach (var i in irodahazak)
{
    szamlalo++;
    if (i.letszamadat.Sum() > max)
    {
        max = i.letszamadat.Sum();
        emeletszam = szamlalo;
    }
}
Console.WriteLine($"8. feladat: Emelet száma: {emeletszam}, összesen {max} fő");

Console.WriteLine("\n");
/*9. Írd ki a képernyőre, hogy van-e olyan iroda, ahol kilencen vannak. Hagyományos kódolásnál
állj meg a feldolgozással, írd ki a cég kódját és az iroda sorszámát. Ha nincs ilyen, írj ki
hibaüzenetet. Ha LINQ-val oldod meg, akkor az eredményből az első cég fenti adatait add meg,
majd a hibaüzenetet.*/
bool asd = false;
string cegkod = string.Empty;
int iszam = 0;

foreach (var i in irodahazak)
{
    for (int a = 0; a < i.letszamadat.Count(); a++)
    {
        if (i.letszamadat[a] == 9)
        {
            asd = true;
            cegkod = i.ceg;
            iszam = a + 1;
        }
    }
}
if (asd)
{
    Console.WriteLine("9. feladat: Van olyan iroda, ahol kilencen vannak:");
    Console.WriteLine($"Cég kódja: {cegkod}, iroda sorszáma: {iszam}");
}
else
{
    Console.WriteLine("Nincs olyan iroda, ahol 9-en vannak!");
}

Console.WriteLine("\n");
//10. Írd ki a képernyőre, hogy hány irodában vannak ötnél többen.

int xd = 0;
foreach (var i in irodahazak)
{
    for (int a = 0; a < i.letszamadat.Count(); a++)
    {
        if (i.letszamadat[a] > 5)
        {
            xd++;
        }
    }
}
Console.WriteLine($"10. feladat: {xd} irodában vannak 5-nél többen");

/*11. Melyik emeletek melyik irodáiban nem dolgozik jelenleg senki? Soronként írd ki egy új fájlba a
cég kódját, mellé szóközzel elválasztva az iroda sorszámát / sorszámait. Ne zárd le a fájlt.*/
using (StreamWriter sw = new StreamWriter(@"..\..\..\src\11feladat.txt"))
{
    foreach (var i in irodahazak)
    {
        for (int a = 0; a < i.letszamadat.Count(); a++)
        {
           
        }
    }
}

Console.WriteLine("\n");
/*12. Írd ki a képernyőre, hogy a LOGMEIN kódú cég irodáiban átlagosan hány személy dolgozik?
(egész számmal)*/

int osszesen = 0;
int mennyi = 0;
foreach (var i in irodahazak)
{
    for (int a = 0; a < i.letszamadat.Count(); a++)
    {
        if (i.ceg == "LOGMEIN")
        {
            osszesen += i.letszamadat[a];
            mennyi += 1;
        }
    }
}
double atlag = osszesen / mennyi;
Console.WriteLine($"12. feladat: A LOGMEIN kódú cég idodáiban átlagosan {Math.Round(atlag,0)} személy dolgozik.");

/*13. Írd ki a fenti fájlba, új sorba folytatólagosan az emeletek sorszáma mellé az adott emeleten
dolgozók számát. Írj egy magyarázó sort a kiírás elé. Zárd le a fájlt.*/

Console.WriteLine("\n");
/*14. Írd ki a képernyőre, hogy hány fő dolgozik összesen az irodaházban.*/
int egeszFo = 0;
foreach (var i in irodahazak)
{
    for (int a = 0; a < i.letszamadat.Count(); a++)
    {
        egeszFo += i.letszamadat[a];
    }
}
Console.WriteLine($"14. feladat: Összesen {egeszFo} fő dolgozik az irodákban.");

Console.WriteLine("\n");
/*15. Írd ki a képernyőre azt az évet, amikor megtörtént az első irodabérlés.*/
int min = irodahazak[0].kezdet;
foreach (var i in irodahazak)
{
    if (i.kezdet < min)
    {
        min = i.kezdet;
    }
}
Console.WriteLine($"15. feladat: Az első irodabérlés {min}-ban/ben történt.");

Console.WriteLine("\n");
/*16. Írd ki a képernyőre, hogy hány éve nem történt új irodabérlés (a rendszerdátumhoz
viszonyítva).*/

int evszam = 2024;
int maxEv = irodahazak[0].kezdet;
foreach (var i in irodahazak)
{
    if (i.kezdet > maxEv)
    {
        maxEv = i.kezdet;
    }
}
int tortent = evszam - maxEv;
Console.WriteLine($"16. feladat: {tortent} éve nem történt új irodabérlés.");

Console.ReadKey();